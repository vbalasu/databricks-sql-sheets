zip -r my-lambda-function.zip .
# Upload this file to AWS Lambda